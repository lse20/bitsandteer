<?php

	require_once('rabbitMQLib.inc');
	
	session_start();
	$userID = $_SESSION['userID'];
	$patientID = $_SESSION['patientID'];
	$brandName = $_SESSION['brandName'];

	$sendArr = array('username'=>$userID,'patientID'=>$patientID, 'brandName'=>$brandName);
	$client = new rabbitMQClient('webSideRMQP.ini','dPortal_T_DB');
	$response = $client->send_request($sendArr);

	unset($_SESSION['patientID']);
	unset($_SESSION['brandName']);

	if($response === true)
	{
		echo "<h4>Medicine successfully added!</h4>";
		header("refresh:1; viewPatient.php");
	}
	else
	{
		echo "<h4>Medicine could not be prescribed</h4>";
		header("refresh:1; viewPatient.php");
	}
?>
