#!/bin/bash

if [ -z "$1" ]

then
	echo "Please give a valid name for the version."

else
 	zip -r "$1.tar" /var/www/html/web/rmqp/htmlPart
	
	zipVar="$1.tar"

	pathVar="/var/www/html/web/rmqp/htmlPart/$zipVar"

	scp $pathVar lou@192.168.1.175:/home/lou/working/versioncontrol

fi
