<?php

	require_once('rabbitMQLib.inc');

	$client = new rabbitMQClient('webSideRMQP.ini','dPortal_T_DMZ');
	
	$arrad
