<?php

	require_once('rabbitMQLib.inc');

	$argv[1] = $defective;
	$function = 'rollBack';
	$ipaddress = '192.168.1.106';
	$username = 'ben2';
	$destination = 'home/ben2/var/www/html/web/rmqp/htmlPart';

	$sendArr = array('function' = $function, 'ipaddress' = $ipaddress, 'username' = $username, 'defVer' = $defective, 'destination' = $destination);

	$client = new rabbitMQClient('webSideRMQP','rollback');
	$response = $client->send_request($sendArr);
	
	if($response === true)
	{
		shell_exec('./unzip '.$response['version']);
		echo "rollback successful";
	}
	else
	{
		echo "rollback failed.  Check logs.";
	}
?>
