<?php 

	require_once('rabbitMQLib.inc');

	$client = new rabbitMQClient("webSideRMQP.ini", "pRegister_T_DB");
	$user = $_POST['username'];
	$pass = $_POST['password'];
	$rePass = $_POST['rePass'];
	$eMail = $_POST['email'];
	$fName = $_POST['fName'];
	$lName = $_POST['lName'];
	$address = $_POST['address'];
	$age = $_POST['age'];
	$hght = $_POST['height'];
	$weight = $_POST['weight'];
	$mHist = $_POST['mHist'];
	$sex = $_POST['sex'];
	$func = "pRegister";

	if($pass != $rePass)
	{
		header("location: pRegister.html");
		echo "<h4>Passwords do not match!</h4>";
		exit();
	}
	else
	{
		$pData = array('user'=>$user, 'pass'=>$pass,'email'=>$eMail, 'fName'=>$fName, 'lName'=>$lName, 'age'=>$age, 'height'=>$hght, 'weight'=>$weight, 'mHist'=>$mHist, 'address'=>$address, 'sex'=>$sex, 'function'=>$func);
		$response = $client->send_request($pData);
		if($response[0] === true)
		{
			echo "<h1>Registration Successful</h1>";
			header("refresh:2; login.html");
		}
		else
		{
			echo "<h1>Registration Failed</h1>";
			header("refresh:2; pRegister.html");
		}
	}
?>
