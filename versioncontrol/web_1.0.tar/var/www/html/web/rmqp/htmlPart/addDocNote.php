<?php
	require_once('rabbitMQLib.inc');

	session_start();
	$userID = $_SESSION['userID'];
	$email = $_SESSION['patientID'];
	//$note = $_POST['drNote'];
	$note = "he needs to diet";
	echo "<h4>".$note."</h4>";
	$client = new rabbitMQClient('webSideRMQP.ini','dPortal_T_DB');
	$sendArr = array('function'=>'docNote','userID'=>$userID, 'note'=>$note, 'email'=>$email);
	$response = $client->send_request($sendArr);
	if($response === true)
	{
		echo "<h4>Note added successfully<h4>";
		header("refresh:1; displayPatient.php");
	}
	else
	{
		echo "<h4>Note failed</h4>";
		header("refresh:1; displayPatient.php");
	}	
?>
