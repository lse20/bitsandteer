<?php
	
	require_once("rabbitMQLib.inc");
	session_start();
	//creates a session
	$userID = $_SESSION['userID'];
	//stores the session ID to a variable

	$client = new rabbitMQClient('webSideRMQP.ini','pPortal_T_DB');
	//creates a new Client object
	$rating = $_POST['rating'];
	//pulls rating from the last and sets it to rating
	$sendArr = array('rating'=>$rating, 'function'=>'rateDoc', 'username'=>$userID);
	//creates an array with the rating set to rating and the function is rateDoc. 
	$client->publish($sendArr);
	//sends the array
	header("location: patientPortal.php");
	//redirects back to the homepage
?>
