<?php

	require_once('rabbitMQLib.inc');
	session_start();
	$userID = $_SESSION['userID'];
	
	$email = $_POST['email'];
	echo "<h1>".$email."</h1>";
	$sendArr = array('function'=>'setDoc','email'=>$email,'username'=>$userID);
	$client = new rabbitMQClient('webSideRMQP.ini','pPortal_T_DB');
	$response = $client->send_request($sendArr);

	if($response === true)
	{
		echo "<h1>Doctor added successfully</h1>";
		header('refresh:1; patientPortal.php');
	}
	else
	{
		echo "<h1>Cannot add Doctor...</h1>";
		header('refresh:1; dSearch.php');
	}
?>
