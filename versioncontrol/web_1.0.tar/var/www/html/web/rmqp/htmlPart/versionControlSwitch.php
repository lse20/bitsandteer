<?php

	require_once('rabbitMQLib.inc');

	function versionSwitch($msg)
	{
		$PASSWORD = 'toor';
		$function = $msg['function'];
		switch($function)
		{
			case "promoteWebQA":		
				$path = "/home/lou/versionControl/webVersion";
				$name = $msg['name'];
				$destination = ":home/ben2/var/www/html/web/rmqp/htmlPart";
				$ipaddress = "ben2@192.168.1.107";
				pushVersion($name, $path, $destination, $ipaddress);
				//add a line of code here that adds $name to the database and the path
				break;
			case "promoteAPIQA":
				$path = "/home/lou/versionControl/APIVersion";
				$name = $msg['name'];
				$destination = ":home/username/public";
				$ipaddress = "user@IPADDRESS";
				pushVersion($name, $path, $destination, $ipaddress);
				break;
			case "rollBack":
				return rollback($msg['defVer'], $msg['ipaddress'], $msg['username'], $msg['destination']);
			default:
				echo "not a valid input.";
		}
	}

	function pushVersion($name, $path, $destination, $ipaddress)
	{
		shell_exec("echo $PASSWORD | sudo scp ".$path."/$name"." $ipaddress:".$destination);
		$info = array('function'=>'promoteWebQA');
		$client = new rabbitMQClient('webSideRMQP.ini','version_push');
		$client->publish($info);
	}
	
	function rollback($defective, $ipaddress, $username, $destination)
	{
		//add a code here that marks $defective (which is the name of the defective version) bad in the database;
		//add a code here that searches the database and pulls the name of the latest non defective version and set it to $name and set $path the path;
		shell_exec("echo $PASSWORD | sudo scp ".$path."/$name"." $ipaddress".$destination);
		return true;
	}

	$server = rabbitMQServer('webSideRMQP.ini','version_control');
	$server->process_request('versionSwitch');
?>
