<?php

	require_once('rabbitMQLib.inc');

	$name = $argv[1];
	$function = $argv[2];
	$PASSWORD = "admin";
	$HISPASS = "toor";
	$name2 = "$name.tar";
	
	switch($function)
	{
		/*case 'promoteLive':
			$msg = array('function'=>$function,'name'=>$name);
			shell_exec("zipFiles.sh ".$name);
			echo "pushed to Web Live";
			break;*/
		case 'promoteWebQA':
			$msg = array('function'=>$function,'name'=>$name);
			shell_exec("echo $PASSWORD | sudo -S ./zipFiles.sh ".$name);
			shell_exec("echo $HISPASS");
			echo "pushed to Web Test";
			break;
		default:
			echo "error:  not a correct function";
			break;
	}

	$client = new rabbitMQClient('webSideRMQP.ini','version_control');
	$client->publish($msg);

?>
