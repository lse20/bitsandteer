<?php
	require_once('rabbitMQLib.inc');

	session_start();
	$userID = $_SESSION['userID'];
	echo "<h1>".$userID."</h1>";

	$client = new rabbitMQClient('webSideRMQP.ini','pPortal_T_DB');
	$sendArr = array('username'=>$userID,'function'=>'displayPatient');
	$display = $client->send_request($sendArr);

	var_dump($display);
	$fname = $display['firstName'];
	$lname = $display['lastName'];
	$age = $display['age'];
	$address = $display['location'];
	$_SESSION['address'] = $address;
	$hgt = $display['height'];
	$weight = $display['weight'];
	$sex = $display['sex'];
	$mHist = $display['diagnosis'];
	$doctor = $display['doctor'];
	$med = $display['prescription'];
	$drNote = $display['drNote'];	
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<h1>Patient Portal</h1><br>
<div class="topnav">
  <a class="active" href="patientPortal.php">Home</a>
  <a class="active" href="checkLocation.php">Check Nearby Walgreens</a>
  <a class="active" href="logout.php">Log Out</a>
  <div class="search-container">
    <form action="dSearch.php" method="post">
      <input type="text" name="searchVar" id="searchVar" placeholder="Search for Doctors.." >
      <select name = "searchType" id="searchType">
	   <option value="byLastName" name="byLastName">by Last Name</option>
           <option value="bySpec" name="bySpec">by Specialization</option>
	   <option value="byEmail" name="byEmail">by Email</option>
        </select>
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
<table frame = "box" style="width:100%">
<caption>Your Personal Information</caption><br>
<thead>
	<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email</th>
		<th>Age</th>
		<th>Address</th>
		<th>Height</th>
		<th>Weight</th>
		<th>Sex</th>
		<th>Medical History</th>
		<th>Appointed Doctor</th>
		<th>Doctor's Note</th>
		<th>Prescriptions</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><center><?php echo $fname ?></center></td>
		<td><center><?php echo $lname ?></center></td>
		<td><center><?php echo $email ?></center></td>
		<td><center><?php echo $age ?></center></td>
		<td><center><?php echo $address ?></center></td>
		<td><center><?php echo $hgt ?></center></td>
		<td><center><?php echo $weight ?></center></td>
		<td><center><?php echo $sex ?></center></td>
		<td><center><?php echo $mHist ?></center></td>
		<td><center><?php echo $doctor ?></center></td>
		<td><center><?php echo $drNote ?></center></td>
		<td><center><?php echo $med ?></center></td>
	</tr>
</tbody>
</table>
</form>
</form>

<form  action="rateDoctor.php" method="post">
Rate Your Doctor: <br><input type="number" name="rating" placeholder = "1 to 5"></input>
	<button type="submit">Rate!</button><br>
</form>
<!-- creates an input field that posts a number to the next page -->

<form  action="review.php" method="post">
 Write a Doctor Review: <br><textarea rows="4" cols"50" type = "text" name = "docRev" placeholder = "Write a Review"></textarea><br>
	<button type="submit">Add A Review</button><br>
</form>

<form action="updatePatientInfo.php">
	<input type = "submit" value="Update Information">
</form>
</form>
</body>
</html>
