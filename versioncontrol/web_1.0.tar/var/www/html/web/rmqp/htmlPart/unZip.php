<?php

	require_once('rabbitMQLib.inc');
	
	function unZip($msg)
	{
		$name = $msg['name'];
		switch($msg['function'])
		{
			case "promoteWebQA":
				shell_exec('unZip.sh '.$name);
				echo "successfully installed.";
				break;
			case "promoteWebLive":
				shell_exec('unZip.sh '.$name);
				echo "successfully installed.";
			default:
				echo "unzip failure; check function message";
				break;
		}
	}
	
	$server = new rabbitMQServer('webSideRMQP.ini','version_push');
	$server->process_request('unZip');
?>
