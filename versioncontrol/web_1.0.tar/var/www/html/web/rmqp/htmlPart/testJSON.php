<?php
	require_once('rabbitMQLib.inc');//use require once to get access to the functions defined in the file that is in the paranthesis
	//require_once('nameOfFunctionFile');

	$client = new rabbitMQClient('testRMQ.ini','testRMQ');
	//creates a new instance of rabbitMQClient and attaches it
	//to the variable $client.  First argument is asking for a
	//path and the second is the name of said path
	//$classVar = new classObject('argument1', 'argument2')
	
	$user = $argv[1];
	$pass = $argv[2];
	$func = $argv[3];

	$sendArr = array();
	//instantiates an array
	$sendArr['user'] = $user;//$sendArr['key'] = $value;
	//$sendArr['key'] = "this is fucking bullshit";
	echo $sendArr['user'];//Junior
	$sendArr = array('user' => $user, 'pass' => $pass, 'func' => $func);//$arrayVar = array('key1' => $value, 'key2' => $value2);
	//$arrayVar = array('key1' => "Junior I'm hungry, get me a sub pls");
	var_dump($sendArr);
	$client->send_request($sendArr);//$classVar->func($var);
?>
