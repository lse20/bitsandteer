#!/bin/bash

name=$1;

path="/var/www/html/web/rmqp/htmlPart"

unzip -f $name $path
