<?php

	require_once('rabbitMQLib.inc');
	
	$client = new rabbitMQClient('webSideRMQP.ini','Login_T_DB');	

	$user = $argv[1];
	$pass = $argv[2];
	$func = $argv[3];
	
	$sendArr = array('username' => $user, 'password' => $pass, 'function' => $func);
	var_dump($sendArr);
	$client->publish($sendArr);

	//$client -> process_response($response);
	
	function yesOrNo($msg)
	{
		var_dump($msg);
		if($msg[0] == 'true')
		{
			$mess = 'login successful';
			exit($mess);
		}
		else
		{
			$mess = 'login failed';
			exit($mess);
		}
	}
	
	echo 'fuuuuuuuuuuuuuuuuuuuuck';

	$server = new rabbitMQServer('webSideRMQP.ini','DB_T_Login');
	$server -> process_requests('yesOrNo');

?>
