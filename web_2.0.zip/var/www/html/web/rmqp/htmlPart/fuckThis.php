<!DOCTYPE html>

<html>
<body>

<h1>Type Random Shit Here!</h1>

<form action="fuckThis.php" method="post">
	Huge Ass Text Box:  <textarea rows="10" cols="50" type="text" name="HATB" placeholder="fuuuuuck"></textarea><br>

<input type="submit" value="Shiiiieeeet">
</form><br>
</body>
</html>

<?php

	require_once('rabbitMQLib.inc');

	$client = new rabbitMQClient("webSideRMQP.ini","Login_T_DB");
	$message = $_POST['HATB'];
	
	$deadAss = array('function' => 'error','log' => $message);
	var_dump($deadAss);
	$client->publish($deadAss);
	header("refresh 1; fuckThis.php");
	exit();
?>
