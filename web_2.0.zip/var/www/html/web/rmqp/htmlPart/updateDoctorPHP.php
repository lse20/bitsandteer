<?php
        require_once("rabbitMQLib.inc");
	session_start();

        $client = new rabbitMQClient("webSideRMQP.ini","dPortal_T_DB");
        $user = $_POST['username'];
        $pass = $_POST['password'];
        $rePass = $_POST['rePass'];
        $eMail = $_POST['email'];
        $telNum = $_POST['telNo'];
        $fName = $_POST['fName'];
        $lName = $_POST['lName'];
        $lNo = $_POST['lNo'];
        $spec = $_POST['spec'];
        $address = $_POST['address'];
        $sex = $_POST['sex'];
        $func = "dRegister";

        if($pass != $rePass)
        {
		echo "<h4>Password does that match</h4>";
                header("refresh:2; updateDoctorInfo.php");
        }
	else
	{
        	$dData = array('username'=>$user, 'password'=>$pass, 'email'=>$eMail, 'fName'=>$fName, 'lName'=>$lName, 'telNo'=>$telNum, 'lNo'=>$lNo, 'spec'=>$spec, 'address'=>$address, 'sex'=>$sex, 'function'=>$func);
        	$response = $client->send_request($dData);
		if($response === true)
		{
			echo "<h1>Update Successful!</h1>";
        		header("refresh:2; doctorPortal.php");
		}
		else
		{
			echo "<h1>Registration Failed</h1>";
			header("refresh:2; updateDoctorInfo.php");
		}
	}
?>
