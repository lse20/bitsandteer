<?php

	require_once('rabbitMQLib.inc');

	$user = $argv[1];
	$pass = $argv[2];
	$func = $argv[3];
	$accType = $argv[4];

	$client = new rabbitMQClient('webSideRMQP.ini','Login_T_DB');
	 
	$sendArr = array('user' => $user, 'pass' => $pass, 'function' => $func, 'accType' => $accType);
	var_dump($sendArr);
	$client->send_request($sendArr);
	$client->process_response($response);
	var_dump($response);
	
?>
