<?php

	require_once("rabbitMQLib.inc");
	session_start();
	$userID = $_SESSION['userID'];
	echo "<h1>".$userID."</h1>";
	
	$searchVar = $_POST['searchVar'];
	$searchType = $_POST['searchType'];
	$sendArr = array('searchVar'=>$searchVar,'searchType'=>$searchType, 'function'=>'docSearch');
	var_dump($sendArr);
	$client = new rabbitMQClient("webSideRMQP.ini","pPortal_T_DB");
	$response = $client->send_request($sendArr);
	var_dump($response);
?>

<!DOCTYPE html>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
/*. means class selector*/
.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

/*a is a link*/
.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/*:hover means changes when cursor is hovering element*/
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/*is a and has an active tag*/
.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<h1>Search Results</h1><br>
<div class="topnav">
  <a class="active" href="patientPortal.php">Home</a>
  <a class="active" href="logout.php">Log Out</a>
  <div class="search-container">
    <form action="dSearch.php" method="post">
      <input type="text" name="searchVar" id="searchVar" placeholder="Search for Doctors.." >
      <select name = "searchType" id="searchType">
	   <option value="byLastName" name="byLastName">by Last Name</option>
           <option value="bySpec" name="bySpec">by Specialization</option>
	   <option value="byEmail" name="byEmail">by Email</option>
        </select>
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
<table frame = "box" style="width:100%">
<caption>Doctor Information</caption><br>
<thead>
	<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Specialization</th>
		<th>Telephone Number</th>
		<th>E-mail</th>
		<th>Address</th>
		<th>Sex</th>
		<th>Rating</th>
		<th>Review</th>
		<!--<th>Add Doctor</th>-->
	</tr>
</thead>
<tbody>
	<tr>
		<tbody>
                            <?php $count = 0; foreach ($response as $array => $value) : ?>
                                <tr>
                                    <td><center><?php echo $response[$count]['firstName']; ?></center></td>
                                    <td><center><?php echo $response[$count]['lastName']; ?></center></td>
                                    <td><center><?php echo $response[$count]['specialization']; ?></center></td>
                                    <td><center><?php echo $response[$count]['phone']; ?></center></td>
                                    <td><center><?php echo $response[$count]['email']; ?></center></td>
				    <td><center><?php echo $response[$count]['location']; ?></center></td>
				    <td><center><?php echo $response[$count]['gender']; ?></center></td>
				    <td><center><?php echo $response[$count]['rating']; ?></center></td>
				    <td><center><?php echo $response[$count]['review']; ?></center></td>

                                    <!--<td>
                                        <form action="addDoctor.php" method="post">
                                            <button type="submit" class="btn btn-block" name="add_doctor">Add this Doctor</button>
                                        </form>
                                    </td>-->
                                    <?php $count++; endforeach; ?>
				</tr>
		</tbody>
	</tr>
</tbody>
</table>
<form  action="addDoctor.php" method="post">
Add Doctor via Email: <br><input type="email" name="email" id="email" placeholder="example@example.com"></input>
	<button type="submit">Add Doctor!</button><br>
</form>
</form>
</form>
	
