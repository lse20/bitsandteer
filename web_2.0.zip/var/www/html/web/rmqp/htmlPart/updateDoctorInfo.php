<?php
	session_start();
?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<h1>Doctor Portal</h1><br>
<div class="topnav">
  <a class="active" href="doctorPortal.php">Home</a>
  <a class="active" href="logout.php">Log Out</a><br><br><br><br>
<form action="updateDocPHP.php" method="post">
        Username: <input type = "text" name = "username"><br>
        Password: <input type = "password" name="password"><br>
        Retype Password: <input type="password" name="rePass"><br>
        E-mail: <input type = "email" name = "email"><br>
        Telephone No: <input type = "tel" name = "telNo"><br>
        First Name: <input type = "text" name="fName"><br>
        Last Name: <input type = "text" name="lName"><br>
        License No.: <input type = "text" name="lNo"><br>
        Specialization: <textarea type = "text" rows = "4" cols = "50" name = "spec" placeholder = "what was your area of expertise in?"></textarea><br>
        Address of Office: <textarea type = "text" rows = "2" cols = "50" name = "address"></textarea><br>
        <select name = "sex">
        Sex: <option value = "" selected>Select Your Sex</option>
             <option value = "m" name = "m">Male</option>
             <option value = "f" name = "f">Female</option>
        </select><br>
        <input type="submit" value="Update!">
</form><br>
</body>
</html>

