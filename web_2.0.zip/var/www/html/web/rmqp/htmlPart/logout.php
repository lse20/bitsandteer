<?php
	//require_once('rabbitMQLib.inc');

	session_start();
	session_unset();
	session_destroy();
	echo "<h1>You have been successfully logged out!</h1>";
	header("refresh:2; login.html");
?>
