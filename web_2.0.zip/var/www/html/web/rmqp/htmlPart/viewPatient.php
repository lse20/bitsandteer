<?php

	require_once('rabbitMQLib.inc');

	$client = new rabbitMQClient("webSideRMQP.ini","dPortal_T_DB");
	
	session_start();
	$userID = $_SESSION['userID'];
	$_SESSION['patientID'] = $_POST['email'];
	$patientID = $_SESSION['patientID'];
	$sendArr = array('function'=>'docViewPat','email'=>$patientID,'userID'=>$userID);
	var_dump($sendArr);
	$display = $client->send_request($sendArr);

	var_dump($display);
	$fname = $display['firstName'];
	$lname = $display['lastName'];
	$age = $display['age'];
	$hgt = $display['height'];
	$weight = $display['weight'];
	$sex = $display['sex'];
	$address = $display['address'];
	$mHist = $display['diagnosis'];
	$med = $display['prescription'];
	$drNote = $display['drNote'];	
?>

<!DOCTYPE html>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
/*. means class selector*/
.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

/*a is a link*/
.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/*:hover means changes when cursor is hovering element*/
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/*is a and has an active tag*/
.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<h1>Doctor Portal</h1><br>
<div class="topnav">
  <a class="active" href="doctorPortal.php">Home</a>
  <a class="active" href="logout.php">Logout</a>
  <div class="search-container">
    <form action="medSearch.php" method="post">
      <input type="text" name="searchVar" id="searchVar" placeholder="Search for Meds.." >
      <!--<select name = "searchType" id="searchType">
		<option value="getGeneralInfo" name="getGeneralInfo">search by Brand</option>
		<option value="getSearch" name="getSearch">search by After Effects</option>
      </select>-->
     <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
<table frame = "box" style="width:100%">
<caption>Detailed Patient Information</caption><br>
<thead>
	<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email</th>
		<th>Age</th>
		<th>Sex</th>
		<th>Address</th>
		<th>Height</th>
		<th>Weight</th>
		<th>Medical History</th>
		<th>Doctor's Note</th>
		<th>Prescriptions</th>
	</tr>
</thead>
<tbody>
	<tbody>
                <tr>
			<td><center><?php echo $fname ?></center></td>
			<td><center><?php echo $lname ?></center></td>
			<td><center><?php echo $email ?></center></td>
			<td><center><?php echo $age ?></center></td>
			<td><center><?php echo $sex ?></center></td>
			<td><center><?php echo $address ?></center></td>
			<td><center><?php echo $hgt ?></center></td>
			<td><center><?php echo $weight ?></center></td>
			<td><center><?php echo $mHist ?></center></td>
			<td><center><?php echo $drNote ?></center></td>
			<td><center><?php echo $med ?></center></td>
		</tr>

	</tbody>
</tbody>
</table>
</form>
</form>

<form action="addDocNote.php" metod="post">
Add a Doctor's Note: <br><textarea type="text" id="drNote" name="drNote" placeholder="Add a Doctor's Note"></textarea><br>
	<button type="submit">Add Note</button><br>
</form>
</body>
</html>
