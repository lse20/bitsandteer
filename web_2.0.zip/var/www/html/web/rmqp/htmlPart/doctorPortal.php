<?php
	require_once('rabbitMQLib.inc');

	session_start();
	$userID = $_SESSION['userID'];
	echo "<h1>".$userID."</h1>";

	$client = new rabbitMQClient('webSideRMQP.ini','dPortal_T_DB');
	$sendArr = array('username'=>$userID,'function'=>'displayDoc');
	$display = $client->send_request($sendArr);

	var_dump($display);
	$fName = $display['firstName'];
	$lName = $display['lastName'];
	$spec = $display['specialization'];
	$telnum = $display['phone'];
	$email = $display['email'];
	$address = $display['location'];
	$sex = $display['gender'];
	$lno = $display['license'];
	$_SESSION['license'] = $lno;
	$rating = $display['rating'];
	$review = $display['review'];

	echo "<h2>".$_SESSION['license']."</h2>";
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<h1>Doctor Portal</h1><br>
<div class="topnav">
  <a class="active" href="doctorPortal.php">Home</a>
  <a class="active" href="logout.php">Log Out</a>
<form  action="displayPatient.php" method="post">
<table frame = "box" style="width:100%">
<caption>Your Personal Information</caption><br>
<thead>
	<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Specialization</th>
		<th>Telephone Number</th>
		<th>E-mail</th>
		<th>Address</th>
		<th>Sex</th>
		<th>License Number</th>
		<th>My Rating</th>
		<th>My Review</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><center><?php echo $fName ?></center></td>
		<td><center><?php echo $lName ?></center></td>
		<td><center><?php echo $spec ?></center></td>
		<td><center><?php echo $telnum ?></center></td>
		<td><center><?php echo $email ?></center></td>
		<td><center><?php echo $address ?></center></td>
		<td><center><?php echo $sex ?></center></td>
		<td><center><?php echo $lno ?></center></td>
		<td><center><?php echo $rating ?></center></td>
		<td><center><?php echo $review ?></center></td>
	</tr>
</tbody>
</table>
<form action="displayPatient.php" method="post">
	<button type="submit">List of Patients</button>
</form><br>
<form action="updateDoctorInfo.php" method="post">
	<button type="submit">Update your Information</button>
</form>
</form>
</form>
</body>
</html>
