<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

	session_start();

        require_once('rabbitMQLib.inc');
	
	$client = new rabbitMQClient("webSideRMQP.ini","Login_T_DB");
        
	$user = $_POST['username'];
        $pass = $_POST['password'];
	//$accType = $_POST['accType'];
        
        /*if($accType == "doctor")
	{
		$func = 'dLogin';
        }
        else
        {
                $func = "pLogin";
        }*/

        $request = array("function"=>"login", "username"=>$user, "password"=>$pass);
	var_dump($request);
        $response = $client->send_request($request);

        echo "SUCCESSSSS!  *in Dexter's voice*".PHP_EOL;

	var_dump($response);

	if($response['0'] == "d")
	{
		$_SESSION['userID'] = $response['userID'];
		header("location: doctorPortal.php");
		exit();
	}
	elseif($response['0'] == "p")
	{
		$_SESSION['userID'] = $response['userID'];
		header("location: patientPortal.php");
		exit();
	}
	else
	{
		header("refresh:2; login.html");
		echo "<h1>login failed</h1>";
	}
	
?>
