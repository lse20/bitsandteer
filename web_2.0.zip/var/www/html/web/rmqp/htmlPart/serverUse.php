#!/usr/bin/php
<?php
	require_once('path.inc');
	require_once('get_host_info.inc');
	require_once('rabbitMQLib.inc')
	
	function makeClient($array)
	{
		$client = new rabbitMQClient("testRabbitMQ.ini","testServer");
		$response = $client->send_request($array);
		return $response;
	}
?>
