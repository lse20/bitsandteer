<?php

	session_start();
	$userID = $_SESSION['userID'];
	
	require_once("rabbitMQLib.inc");

	$client = new rabbitMQClient('webSideRMQP.ini','Login_T_DB');
	$rev = $_POST['docRev'];
	$sendArr = array('username'=>$userID, 'rev'=>$rev, 'function'=>'wRev');
	$client->publish($sendArr);
	header("location: patientPortal.php");
?>
	
