<?php
	
	require_once("rabbitMQLib.inc");
	session_start();
	$userID = $_SESSION['userID'];

	$client = new rabbitMQClient('webSideRMQP.ini','pPortal_T_DB');
	$rating = $_POST['rating'];
	$sendArr = array('rating'=>$rating, 'function'=>'rateDoc', 'username'=>$userID);
	$client->publish($sendArr);
	header("location: patientPortal.php");
?>
