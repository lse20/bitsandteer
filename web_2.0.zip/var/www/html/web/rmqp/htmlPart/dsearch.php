<?php
	session_start();
	$_SESSION['username'];
	$_SESSION['password'];
	$_SESSION['email'];

?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="patientPortal.php">Home</a>
  <a href="#about">About</a>
  <a href="#contact">Contact</a>

</div>
<table frame = "box" style="width:100%">
<caption>List of Doctors</caption><br>
<thead>
	<tr>
		<th>Doctor Name</th>
<!--href the name to bring them to the doctor's page so they can add them-->
		<!--<th>Doctor Last name</th>-->
		<th>Sex<th>
		<th>Specialization</th>
		<th>Email</th>
		<th>Telephone Number</th>
		<th>Office Address</th>
		<th>Add Doctor</th>
	</tr>
</thead>
<script>
<?php

		require_once('rabbitMQLib.inc');

		function addDoctor($buttonNo)
		{
			$func = "addDoctor";
			$name = $doctor[$buttonNo]['name'];
			$spec = $doctor[$buttonNo]['spec'];
			$dSearch = array('name'=>$name,'spec'=>$spec);
			$client = new rabbitMQClient('webSideRMQP.ini','dSearch_T_DB');
			$client->send_request($dSearch);
			header("refresh 2 ; patientPortal.php");
		}

		function displayDoctors($msg)
		{
			foreach($i = 0; $i<count($msg); i++)
			{
				$doctor = array();
				$doctor[$i]['name'] = $msg[$i]['name'];
				$doctor[$i]['spec'] = $msg[$i]['spec'];
				echo "<tr>";
				echo "<td>".$msg[$i]['name']."</td>";
				echo "<td>".$msg[$i]['sex']."</td>";
				echo "<td>".$msg[$i]['spec']."</td>";
				echo "<td>".$msg[$i]['email']."</td>";
				echo "<td>".$msg[$i]['tellNo']."</td>";
				echo "<td>".$msg[$i]['address']."</td>";
				echo "<td><button name='$i' type='button' onclick='addDoctor(this.name)'>Add</button></td>";
				echo "</tr>";
			}
		}

		$server = new rabbitMQServer("webSideRMQP.ini","DB_T_dSearch");
		$server->process_requests('displayDoctors');
?>
</script>
</body>
</html>
